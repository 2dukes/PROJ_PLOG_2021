## PLOG 2020/21 - TP2
### C-Note_4 - Programação em Lógica com Restrições

### Instruções de utilização
- Consultar o ficheiro 'cnote.pl' no terminal do SICStus Prolog
- Executar o predicado cnote/0
- Escolher a opção desejada no menu inserindo o dígito correspondente: 1- Inserir puzzle para resolver, 2- Gerar um novo puzzle, 3- Escolher um puzzle pré-definido para resolver, 4- Aspetos gerais do puzzle.

